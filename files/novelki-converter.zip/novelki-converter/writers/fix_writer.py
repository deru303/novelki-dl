import os
from glob import iglob
from utils import file_rewrite

class FixWriter:
    """Klasa odpowiedzialna za delikatne naprawienie "nieco popsutego formatowania" w niektórych nowelkach."""

    def __init__(self, novel_data, logger, additional_args=None):
        self.additional_args = dict() if additional_args is None else additional_args
        self.logger = logger
        self.novel_data = novel_data

    def write(self):
        self.logger("Rozpoczynam naprawianie formatowania książki.")

        for chapter_path in iglob(os.path.join("tmp", "text", "*.html")):
            print("Kasuję nadmiarowe znaczniki końca linii w pliku: " + chapter_path)
            with open(chapter_path, "r+", encoding="UTF-8") as chapter_file:
                chapter_html = chapter_file.read()
                chapter_html = chapter_html.replace("<p><br>", "<p>").replace("<p><br/>", "<p>").replace("<p><br />", "<p>")
                file_rewrite(chapter_file, chapter_html)

        self.logger("Zakończyłem naprawianie formatowania książki.")