import os
import re
import requests
import shutil
from PIL import Image
from io import StringIO
from glob import iglob
from utils import file_rewrite


class ImageWriter:
    """Klasa odpowiedzialna za pobranie i zapisanie plików obrazków."""

    def __init__(self, novel_data, logger, additional_args=None):
        self.additional_args = dict() if additional_args is None else additional_args
        self.logger = logger
        self.novel_data = novel_data

    def write(self):
        self.logger("Rozpoczynam pobieranie i zapisywanie obrazków")
        image_counter = 0

        for chapter_path in iglob(os.path.join("tmp", "text", "*.html")):
            print("Sprawdzam, czy są jakieś obrazki do pobrania: " + chapter_path)
            with open(chapter_path, "r+", encoding="UTF-8") as chapter_file:
                chapter_html = chapter_file.read()
                image_srcs = re.findall("<img src=[\"']([^\"']*)[\"']", chapter_html)

                for image_src in image_srcs:
                    try:
                        image_src = image_src.replace("&amp;", "&")
                        print("Pobieram: " + image_src)
                        response = requests.get(image_src, stream=True, headers={'User-Agent': 'Mozilla/5.0'})
                        image = Image.open(response.raw)
                        image.save(f"tmp/images/image-{image_counter}.jpeg")
                        del response
                        del image
                    except:
                        shutil.copy("template/image-error.jpeg", f"tmp/images/image-{image_counter}.jpeg")
                        print("Wystąpił błąd przy pobieraniu obrazka, podmieniono obrazek na placeholder.")
                    finally:
                        chapter_html = chapter_html.replace(image_src, f"../images/image-{image_counter}.jpeg")
                        image_counter += 1

                file_rewrite(chapter_file, chapter_html)

        self.logger("Zapisuję informacje o obrazkach w metadanych ebooka")
        with open("tmp/content.opf", "r+", encoding='utf-8') as content_opf:
            opf_content = content_opf.read()
            image_declarations = StringIO()
            for image_index in range(0, image_counter):
                image_declarations.write(f'<item href="images/image-{image_index}.jpeg" id="image-{image_index}" media-type="image/jpeg"/>\n\t\t')
            opf_content = opf_content.replace("!IMAGE_DECLARATIONS!", image_declarations.getvalue())
            file_rewrite(content_opf, opf_content)

        self.logger("Zakończyłem pobieranie i zapisywanie obrazków")
