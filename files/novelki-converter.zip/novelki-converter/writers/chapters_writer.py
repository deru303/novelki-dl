from utils import file_rewrite


class ChaptersWriter:
    """Klasa odpowiedzialna za zapisanie tekstu poszczególnych rozdziałów do plików ebooka."""

    def __init__(self, novel_data, logger, additional_args=None):
        self.additional_args = dict() if additional_args is None else additional_args
        self.logger = logger
        self.novel_data = novel_data

    def write(self):
        self.logger("Rozpoczynam zapisywanie tekstu poszczególnych rozdziałów.")
        text_declarations = ""
        text_id_declarations = ""
        navpoint_declarations = ""

        with open("template/page-template.html", "r") as page_template:
            page_template = page_template.read()

        for chapter_index, chapter in enumerate(self.novel_data["fetched_chapters"]):
            chapter_name, chapter_content = chapter
            chapter_filename = f"tmp/text/part-{chapter_index}.html"
            chapter_ebook_filename = f"text/part-{chapter_index}.html"
            self.logger(f"Analizuję rozdział: {chapter_name}")

            with open(chapter_filename, "w", encoding='utf-8') as chapter_file:
                chapter_html = page_template
                chapter_html = chapter_html.replace("!CHAPTER_NAME!", chapter_name)
                chapter_html = chapter_html.replace("!CHAPTER_HTML!", chapter_content)
                chapter_file.write(chapter_html)

                text_declarations += f"<item href='{chapter_ebook_filename}' id='part-{chapter_index}' media-type='application/xhtml+xml'/>\n\t\t"
                text_id_declarations += f"<itemref idref='part-{chapter_index}'/>\n\t\t"

                navpoint_declarations += f"<navPoint playOrder='{chapter_index + 1}' id='part-{chapter_index}'><navLabel><text>{chapter_name}</text></navLabel><content src='{chapter_ebook_filename}'/></navPoint>\n\t\t"

        self.logger("Zapisuję wygenerowane dane rozdziałów do odpowiednich plików ebooka.")
        with open("tmp/content.opf", "r+", encoding="UTF-8") as content_opf, open("tmp/toc.ncx", "r+", encoding="UTF-8") as toc_ncx:
            opf_content = content_opf.read()
            opf_content = opf_content.replace("!TEXT_DECLARATIONS!", text_declarations)
            opf_content = opf_content.replace("!TEXT_IDS!", text_id_declarations)
            file_rewrite(content_opf, opf_content)

            ncx_content = toc_ncx.read()
            ncx_content = ncx_content.replace("!NAV_POINTS!", navpoint_declarations)
            file_rewrite(toc_ncx, ncx_content)
        self.logger("Zapisywanie danych zakończone pomyślnie.")