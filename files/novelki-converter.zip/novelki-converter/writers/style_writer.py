import os
import re
from glob import iglob
from utils import file_rewrite
from io import StringIO


class StyleWriter:
    """Klasa odpowiedzialna za wprowadzenie modyfikacji wyglądu w plikach ebooka"""

    def __init__(self, novel_data, logger, additional_args=None):
        self.additional_args = dict() if additional_args is None else additional_args
        self.logger = logger
        self.novel_data = novel_data

    def write(self):
        self.logger("Rozpoczynam modyfikację wyglądu nowelki")
        with open("tmp/main.css", "r+") as main_css:
            css_content = main_css.read()
            if self.additional_args.get("paragraph", "block") == "indent":  # indent
                self.logger("Ustawiam metodę oddzielenia paragrafów na: wcięcia")
                indent_size = self.additional_args.get("spacing", "1.5em")
                css_content = css_content.replace("!INDENT_METHOD!", f"text-indent: {indent_size}; margin: 0;")
            else:  # block
                self.logger("Ustawiam metodę oddzielenia paragrafów na: paragrafy blokowe")
                margin_size = self.additional_args.get("spacing", "0.56em")
                css_content = css_content.replace("!INDENT_METHOD!", f"text-indent: 0; margin-top: {margin_size}; margin-bottom: {margin_size};")
            file_rewrite(main_css, css_content)

        if self.additional_args.get("convert-to-hyphens", False) is True:
            for chapter_path in iglob(os.path.join("tmp", "text", "*.html")):
                print("Podmieniam cudzysłowy na myślniki w pliku: " + chapter_path)
                with open(chapter_path, "r+", encoding="UTF-8") as chapter_file:
                    chapter_builder = StringIO()
                    for line in chapter_file.readlines():
                        chapter_line = line
                        if chapter_line.startswith("<p>\""):
                            chapter_line = chapter_line.replace("<p>\"", "<p>- ", 1)
                            chapter_line = chapter_line[::-1].replace("\"", "", 1)[::-1]
                        if chapter_line.startswith("<p>„"):
                            chapter_line = chapter_line.replace("<p>„", "<p>- ", 1)
                            chapter_line = chapter_line[::-1].replace("”", "", 1)[::-1]

                        chapter_builder.write(chapter_line)
                    file_rewrite(chapter_file, chapter_builder.getvalue())

        self.logger("Zakończyłem modyfikację wyglądu nowelki")
