from utils import file_rewrite


class MetadataWriter:
    """Klasa odpowiedzialna za zapisanie metadanych o książce do plików ebooka."""

    def __init__(self, novel_data, logger, additional_args=None):
        self.additional_args = dict() if additional_args is None else additional_args
        self.logger = logger
        self.novel_data = novel_data

    def write(self):
        self.logger("Rozpoczynam zapisywanie metadanych książki.")
        with open("tmp/content.opf", "r+", encoding="utf-8") as content_opf, open("tmp/toc.ncx", "r+", encoding="utf-8") as toc_ncx:
            ncx_content = toc_ncx.read()
            opf_content = content_opf.read()

            ncx_content = ncx_content.replace("!BOOK_TITLE!", self.novel_data["name"])
            opf_content = opf_content.replace("!BOOK_TITLE!", self.novel_data["name"])
            opf_content = opf_content.replace("!BOOK_AUTHOR!", self.novel_data["author"])

            file_rewrite(toc_ncx, ncx_content)
            file_rewrite(content_opf, opf_content)
        self.logger("Zakończyłem zapisywanie metadanych książki.")