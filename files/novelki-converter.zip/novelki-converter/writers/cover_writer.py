import requests
import shutil
from PIL import Image
from utils import file_rewrite

class CoverWriter:
    """Klasa odpowiedzialna za pobranie okładki i zapisanie jej do plików ebooka."""

    def __init__(self, novel_data, logger, additional_args=None):
        self.additional_args = dict() if additional_args is None else additional_args
        self.logger = logger
        self.novel_data = novel_data

    def write(self):
        self.logger("Rozpoczynam pobieranie okładki.")
        if len(self.novel_data["cover_img"]) > 3:
            response = requests.get(self.novel_data["cover_img"], stream=True, headers={'User-Agent': 'Mozilla/5.0'})
            with open('tmp/cover.jpeg', 'wb') as out_file:
                shutil.copyfileobj(response.raw, out_file)
            del response

            with Image.open("tmp/cover.jpeg") as cover, open("tmp/titlepage.xhtml", "r+") as titlepage:
                width, height = cover.size
                file_content = titlepage.read()
                file_content = file_content.replace("!COVER_WIDTH!", str(width))
                file_content = file_content.replace("!COVER_HEIGHT!", str(height))
                file_rewrite(titlepage, file_content)

            self.logger("Pobieranie i zapisywanie danych okładki zakończone.")
        else:
            self.logger("Nie odnaleziono okładki do pobrania.")
