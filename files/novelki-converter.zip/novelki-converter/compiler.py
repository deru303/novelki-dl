import os
import shutil

class EpubCompiler:
    """Klasa kompilująca wskazany folder do postaci pliku .epub o podanej nazwie"""

    def __init__(self, epub_name, epub_directory="tmp"):
        self.epub_name = epub_name
        self.epub_directory = epub_directory

    def compile(self):
        shutil.make_archive(self.epub_name, 'zip', self.epub_directory)
        shutil.move(f"{self.epub_name}.zip", f"{self.epub_name}.epub")
