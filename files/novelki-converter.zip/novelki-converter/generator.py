import os
import shutil
import requests
from compiler import EpubCompiler
from writers import *

class EpubGenerator:
    """Klasa generuje plik .epub na podstawie przekazanych danych nowelki"""

    def __init__(self, novel_data: dict, additional_args=None):
        self.additional_args = dict() if additional_args is None else additional_args
        self.css_modificators = additional_args
        self.novel_data = novel_data

    @staticmethod
    def initialize_tmp():
        try:
            shutil.rmtree("tmp")
        except FileNotFoundError:
            pass
        shutil.copytree("template", "tmp")

    def run_writers(self):
        writers = [CoverWriter, MetadataWriter, ChaptersWriter, FixWriter, StyleWriter, ImageWriter]
        for writer in writers:
            writer(self.novel_data, lambda msg: print(msg), self.additional_args).write()

    def generate(self):
        EpubGenerator.initialize_tmp()
        self.run_writers()
        os.remove("tmp/image-error.jpeg")
        os.remove("tmp/page-template.html")
        EpubCompiler("output/" + self.novel_data["code_name"]).compile()
        shutil.rmtree("tmp")
