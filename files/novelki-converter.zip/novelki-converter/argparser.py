import argparse

argparser = argparse.ArgumentParser(
    description="Narzędzie do konwersji plików .nov.json do .epub",
    epilog="Made by Daniel 'Deru' Rogowski"
)

argparser.add_argument(
    "-p", "--paragraph",
    dest="paragraph", metavar="rodzaj_akapitów",
    type=str, choices=["indent", "block"],
    default="block",
    help="Rodzaj oddzielania poszczególnych akapitów (wcięcia - indent, czy odstępy - block)"
)

argparser.add_argument(
    "-s", "--spacing",
    dest="spacing", metavar="rozmiar_odstępu",
    type=str, default=None,
    help="Rozmiar wcięcia lub odstępu między poszczegolnymi akapitami (w jednostkach CSS)"
)

argparser.add_argument(
    "-c", "--convert-to-hyphens",
    dest="convert_to_hyphens",
    action="store_true",
    default=None,
    help="Obecność tej flagi włącza konwersję cudzysłowów na myślniki"
)

argparser.add_argument(
    dest="nov_json_path",
    type=str,
    help="Ścieżka do pliku .nov.json z danymi nowelki"
)