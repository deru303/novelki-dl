def file_rewrite(file_obj, new_content):
    """Nadpisuje wskazany plik, czyszcząc go i wstawiając do niego żądaną zawartość"""
    file_obj.seek(0, 0)
    file_obj.truncate()
    file_obj.write(new_content)
