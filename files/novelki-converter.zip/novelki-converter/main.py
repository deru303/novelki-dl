import os
import sys
import json
from argparser import argparser
from generator import EpubGenerator

if __name__ == '__main__':
    abspath = os.path.abspath(sys.argv[0])
    dname = os.path.dirname(abspath)
    os.chdir(dname)

    args = argparser.parse_args()

    with open(args.nov_json_path, "r", encoding='utf-8') as f:
        data = json.loads(f.read())
        gen_args = {
            "convert-to-hyphens": args.convert_to_hyphens,
            "spacing": args.spacing,
            "paragraph": args.paragraph
        }

        if gen_args["convert-to-hyphens"] is None:
            gen_args.pop("convert-to-hyphens")
        if gen_args["spacing"] is None:
            gen_args.pop("spacing")

        EpubGenerator(data, gen_args).generate()

